PlatformElement.extend({
    initialize.function(){
        this.settings.get("name");
        console.log(this)
    }
});