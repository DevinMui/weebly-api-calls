PlatformElement.extend({
    initialize.function(){
        this.settings.get("name");
        var x = this
        document.write(x)
    }
});