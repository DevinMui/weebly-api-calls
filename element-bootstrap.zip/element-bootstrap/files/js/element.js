/**
 * This is required for element rendering to be possible
 * @type {PlatformElement}
 */
(function(){

	var MyElement = PlatformElement.extend({});
	
	return MyElement;
})();
